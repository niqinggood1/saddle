import setuptools

setuptools.setup(
    name="saddle",
    version="0.1.0",
    author="patrickNi",
    author_email="niqinggood@gmail.com",
    description="Use this package to make machine Learn Algorithm more convenient ",
    long_description="made by Patrick",
    long_description_content_type="text",
    url="",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)